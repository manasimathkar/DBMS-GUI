# DatabasewithJava

1. Download Apache Netbeans from this link https://netbeans.apache.org/download/nb120/nb120.html

2. Create a new project Java with Maven, And give whatever name you fee like to the project and under source packages/your.package.name create a new JFrame Panel

2. Add JDBC from here https://dev.mysql.com/downloads/connector/j/ and put the mysql-connector-java-8.0.21.jar file in dependencies folder inside the project and Instantiate a database locally for the project to work.




How to make this project
https://www.youtube.com/watch?v=F4vpJJH2PZU
